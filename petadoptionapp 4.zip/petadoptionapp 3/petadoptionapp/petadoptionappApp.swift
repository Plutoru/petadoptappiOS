//
//  petadoptionappApp.swift
//  petadoptionapp
//
//  Created by STUDENT on 9/9/26.
//


import SwiftUI

@main
struct PetAdoptionApp: App {
    @StateObject private var controller = AppController()
    
    var body: some Scene {
        WindowGroup {
            if controller.isLoggedIn {
                MainTabView()
                    .environmentObject(controller)
                    .preferredColorScheme(controller.selectedTheme.colorScheme)
            } else {
                LoginView()
                    .environmentObject(controller)
                    .preferredColorScheme(controller.selectedTheme.colorScheme)
            }
        }
    }
}
