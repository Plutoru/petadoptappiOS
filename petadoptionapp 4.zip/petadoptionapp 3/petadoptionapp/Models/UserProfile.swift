//
//  UserProfile.swift
//  petadoptionapp
//
//  Created by STUDENT on 9/9/26.
//


import Foundation
import UIKit

struct UserProfile: Codable {
    var name: String
    var handle: String
    var email: String
    var password: String
    var location: String
    var isVerified: Bool
    var bio: String
    var postedCount: Int
    var adoptedOutCount: Int
    var savedCount: Int
    var showLocation: Bool = true
    var uiImage: UIImage?
    
    enum CodingKeys: String, CodingKey {
        case name, handle, email, password, location, isVerified, bio
        case postedCount, adoptedOutCount, savedCount, showLocation
        case imageData
    }
    
    init(
        name: String,
        handle: String,
        email: String = "james@example.com",
        password: String = "password123",
        location: String,
        isVerified: Bool,
        bio: String,
        postedCount: Int,
        adoptedOutCount: Int,
        savedCount: Int,
        showLocation: Bool = true,
        uiImage: UIImage? = nil
    ) {
        self.name = name
        self.handle = handle
        self.email = email
        self.password = password
        self.location = location
        self.isVerified = isVerified
        self.bio = bio
        self.postedCount = postedCount
        self.adoptedOutCount = adoptedOutCount
        self.savedCount = savedCount
        self.showLocation = showLocation
        self.uiImage = uiImage
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        name = try container.decode(String.self, forKey: .name)
        handle = try container.decode(String.self, forKey: .handle)
        email = try container.decodeIfPresent(String.self, forKey: .email) ?? "james@example.com"
        password = try container.decodeIfPresent(String.self, forKey: .password) ?? "password123"
        location = try container.decode(String.self, forKey: .location)
        isVerified = try container.decode(Bool.self, forKey: .isVerified)
        bio = try container.decode(String.self, forKey: .bio)
        postedCount = try container.decodeIfPresent(Int.self, forKey: .postedCount) ?? 0
        adoptedOutCount = try container.decodeIfPresent(Int.self, forKey: .adoptedOutCount) ?? 0
        savedCount = try container.decodeIfPresent(Int.self, forKey: .savedCount) ?? 0
        showLocation = try container.decodeIfPresent(Bool.self, forKey: .showLocation) ?? true
        if let data = try container.decodeIfPresent(Data.self, forKey: .imageData) {
            uiImage = UIImage(data: data)
        } else {
            uiImage = nil
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        try container.encode(handle, forKey: .handle)
        try container.encode(email, forKey: .email)
        try container.encode(password, forKey: .password)
        try container.encode(location, forKey: .location)
        try container.encode(isVerified, forKey: .isVerified)
        try container.encode(bio, forKey: .bio)
        try container.encode(postedCount, forKey: .postedCount)
        try container.encode(adoptedOutCount, forKey: .adoptedOutCount)
        try container.encode(savedCount, forKey: .savedCount)
        try container.encode(showLocation, forKey: .showLocation)
        try container.encodeIfPresent(uiImage?.pngData(), forKey: .imageData)
    }
}
