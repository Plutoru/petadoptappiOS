//
//  Pet.swift
//  petadoptionapp
//
//  Created by STUDENT on 9/9/26.
//

//
//  Pet.swift
//  petadoptionapp
//

import Foundation
import UIKit

enum PetStatus: String, CaseIterable, Identifiable, Codable {
    case active = "Active"
    case adopted = "Adopted"
    
    var id: String { rawValue }
}

struct Pet: Identifiable, Codable {
    let id: UUID
    let name: String
    let breed: String
    var age: String // CHANGED FROM let to var
    let gender: String
    let category: String
    var location: String // CHANGED FROM let to var
    let tags: [String]
    var posterName: String
    var adopterName: String?
    let likesCount: Int
    let imageName: String
    var uiImage: UIImage?
    var bio: String
    var isSaved: Bool = false
    var status: PetStatus = .active
    
    enum CodingKeys: String, CodingKey {
        case id, name, breed, age, gender, category, location, tags
        case posterName, adopterName, likesCount, imageName, bio, isSaved, status
        case imageData
    }
    
    init(
        id: UUID = UUID(),
        name: String,
        breed: String,
        age: String,
        gender: String,
        category: String,
        location: String,
        tags: [String],
        posterName: String,
        adopterName: String? = nil,
        likesCount: Int,
        imageName: String,
        uiImage: UIImage?,
        bio: String,
        isSaved: Bool = false,
        status: PetStatus = .active
    ) {
        self.id = id
        self.name = name
        self.breed = breed
        self.age = age
        self.gender = gender
        self.category = category
        self.location = location
        self.tags = tags
        self.posterName = posterName
        self.adopterName = adopterName
        self.likesCount = likesCount
        self.imageName = imageName
        self.uiImage = uiImage
        self.bio = bio
        self.isSaved = isSaved
        self.status = status
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        breed = try container.decode(String.self, forKey: .breed)
        age = try container.decode(String.self, forKey: .age)
        gender = try container.decode(String.self, forKey: .gender)
        category = try container.decode(String.self, forKey: .category)
        location = try container.decode(String.self, forKey: .location)
        tags = try container.decode([String].self, forKey: .tags)
        posterName = try container.decode(String.self, forKey: .posterName)
        adopterName = try container.decodeIfPresent(String.self, forKey: .adopterName)
        likesCount = try container.decode(Int.self, forKey: .likesCount)
        imageName = try container.decode(String.self, forKey: .imageName)
        bio = try container.decode(String.self, forKey: .bio)
        isSaved = try container.decodeIfPresent(Bool.self, forKey: .isSaved) ?? false
        status = try container.decodeIfPresent(PetStatus.self, forKey: .status) ?? .active
        if let data = try container.decodeIfPresent(Data.self, forKey: .imageData) {
            uiImage = UIImage(data: data)
        } else {
            uiImage = nil
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(name, forKey: .name)
        try container.encode(breed, forKey: .breed)
        try container.encode(age, forKey: .age)
        try container.encode(gender, forKey: .gender)
        try container.encode(category, forKey: .category)
        try container.encode(location, forKey: .location)
        try container.encode(tags, forKey: .tags)
        try container.encode(posterName, forKey: .posterName)
        try container.encodeIfPresent(adopterName, forKey: .adopterName)
        try container.encode(likesCount, forKey: .likesCount)
        try container.encode(imageName, forKey: .imageName)
        try container.encode(bio, forKey: .bio)
        try container.encode(isSaved, forKey: .isSaved)
        try container.encode(status, forKey: .status)
        try container.encodeIfPresent(uiImage?.pngData(), forKey: .imageData)
    }
}
