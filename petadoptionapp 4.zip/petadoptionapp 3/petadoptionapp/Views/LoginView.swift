//
//  LoginView.swift
//  petadoptionapp
//
//  Created by STUDENT on 11/16/26.
//

import SwiftUI

struct LoginView: View {
    @EnvironmentObject var controller: AppController
    
    @State private var isLoginMode = true
    @State private var email = ""
    @State private var password = ""
    @State private var name = ""
    @State private var isPasswordVisible = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        ZStack {
            // Background
            Color(hex: "#F9F6F0").ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 24) {
                    
                    Spacer().frame(height: 40)
                    
                    // Logo
                    Image(systemName: "pawprint.fill")
                        .font(.system(size: 50))
                        .foregroundColor(Color(hex: "#C8623A"))
                        .padding(24)
                        .background(Color(hex: "#C8623A").opacity(0.15))
                        .cornerRadius(24)
                    
                    // Titles
                    VStack(spacing: 8) {
                        Text("PawMatch")
                            .font(.system(size: 36, weight: .bold, design: .serif))
                            .foregroundColor(.primary)
                        Text("Find your perfect companion")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    // Main Card
                    VStack(spacing: 20) {
                        
                        // Segmented Control
                        HStack(spacing: 0) {
                            Button(action: { withAnimation { isLoginMode = true } }) {
                                Text("Log In")
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundColor(isLoginMode ? Color(hex: "#C8623A") : .secondary)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                                    .background(isLoginMode ? Color.white : Color.clear)
                                    .cornerRadius(12)
                                    .shadow(color: isLoginMode ? Color.black.opacity(0.05) : .clear, radius: 4, y: 2)
                            }
                            
                            Button(action: { withAnimation { isLoginMode = false } }) {
                                Text("Sign Up")
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundColor(!isLoginMode ? Color(hex: "#C8623A") : .secondary)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                                    .background(!isLoginMode ? Color.white : Color.clear)
                                    .cornerRadius(12)
                                    .shadow(color: !isLoginMode ? Color.black.opacity(0.05) : .clear, radius: 4, y: 2)
                            }
                        }
                        .padding(4)
                        .background(Color(hex: "#F3EFEA"))
                        .cornerRadius(14)
                        
                        if !isLoginMode {
                            // Name Field (Sign Up only)
                            VStack(alignment: .leading, spacing: 8) {
                                Text("FULL NAME")
                                    .font(.caption2.weight(.bold))
                                    .foregroundColor(.secondary)
                                
                                HStack {
                                    Image(systemName: "person")
                                        .foregroundColor(.secondary)
                                    TextField("John Doe", text: $name)
                                        .autocapitalization(.words)
                                }
                                .padding()
                                .background(Color(hex: "#F9F6F0"))
                                .cornerRadius(12)
                                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.2), lineWidth: 1))
                            }
                        }
                        
                        // Email Field
                        VStack(alignment: .leading, spacing: 8) {
                            Text("EMAIL")
                                .font(.caption2.weight(.bold))
                                .foregroundColor(.secondary)
                            
                            HStack {
                                Image(systemName: "envelope")
                                    .foregroundColor(.secondary)
                                TextField("you@email.com", text: $email)
                                    .keyboardType(.emailAddress)
                                    .autocapitalization(.none)
                            }
                            .padding()
                            .background(Color(hex: "#F9F6F0"))
                            .cornerRadius(12)
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.2), lineWidth: 1))
                        }
                        
                        // Password Field
                        VStack(alignment: .leading, spacing: 8) {
                            Text("PASSWORD")
                                .font(.caption2.weight(.bold))
                                .foregroundColor(.secondary)
                            
                            HStack {
                                Image(systemName: "lock")
                                    .foregroundColor(.secondary)
                                
                                if isPasswordVisible {
                                    TextField("••••••••", text: $password)
                                } else {
                                    SecureField("••••••••", text: $password)
                                }
                                
                                Button(action: { isPasswordVisible.toggle() }) {
                                    Image(systemName: isPasswordVisible ? "eye.slash" : "eye")
                                        .foregroundColor(.secondary)
                                }
                            }
                            .padding()
                            .background(Color(hex: "#F9F6F0"))
                            .cornerRadius(12)
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.2), lineWidth: 1))
                        }
                        
                        if isLoginMode {
                            HStack {
                                Spacer()
                                Button("Forgot password?") {
                                    // Placeholder
                                }
                                .font(.caption)
                                .foregroundColor(Color(hex: "#C8623A"))
                            }
                        }
                        
                        // Main Action Button
                        Button(action: handleAuth) {
                            Text(isLoginMode ? "Log In" : "Sign Up")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color(hex: "#C8623A"))
                                .cornerRadius(14)
                        }
                        .padding(.top, 8)
                    }
                    .padding(24)
                    .background(Color.white)
                    .cornerRadius(24)
                    .shadow(color: Color.black.opacity(0.05), radius: 10, y: 5)
                    .padding(.horizontal)
                    
                    // Divider
                    HStack {
                        Rectangle().fill(Color.gray.opacity(0.2)).frame(height: 1)
                        Text("or continue with")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 8)
                        Rectangle().fill(Color.gray.opacity(0.2)).frame(height: 1)
                    }
                    .padding(.horizontal, 40)
                    
                    // Social Buttons
                    HStack(spacing: 16) {
                        SocialLoginButton(icon: "globe", text: "Google", color: .blue)
                        SocialLoginButton(icon: "applelogo", text: "Apple", color: .primary)
                    }
                    .padding(.horizontal)
                    
                    // Footer
                    Button(action: { withAnimation { isLoginMode.toggle() } }) {
                        HStack(spacing: 4) {
                            Text(isLoginMode ? "Don't have an account?" : "Already have an account?")
                                .foregroundColor(.secondary)
                            Text(isLoginMode ? "Sign up free" : "Log in")
                                .foregroundColor(Color(hex: "#C8623A"))
                                .fontWeight(.semibold)
                        }
                        .font(.footnote)
                    }
                    .padding(.top, 10)
                    
                    Spacer().frame(height: 40)
                }
            }
        }
        .alert("Notice", isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }
    
    private func handleAuth() {
        if email.isEmpty || password.isEmpty || (!isLoginMode && name.isEmpty) {
            alertMessage = "Please fill in all fields."
            showAlert = true
            return
        }
        
        if isLoginMode {
            if !controller.login(email: email, password: password) {
                alertMessage = "Invalid email or password.\n\nHint: Use the default test account:\nEmail: james@example.com\nPassword: password123"
                showAlert = true
            }
        } else {
            controller.signUp(name: name, email: email, password: password)
        }
    }
}

// Simple reusable social login button
struct SocialLoginButton: View {
    let icon: String
    let text: String
    let color: Color
    
    var body: some View {
        Button(action: {}) {
            HStack(spacing: 8) {
                if icon == "globe" {
                    // Emulate Google's colorful G with a simple circle
                    Circle().fill(Color.blue).frame(width: 16, height: 16)
                } else {
                    Image(systemName: icon)
                        .foregroundColor(color)
                }
                Text(text)
                    .font(.subheadline.weight(.medium))
                    .foregroundColor(.primary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.white)
            .cornerRadius(12)
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.2), lineWidth: 1))
        }
    }
}
