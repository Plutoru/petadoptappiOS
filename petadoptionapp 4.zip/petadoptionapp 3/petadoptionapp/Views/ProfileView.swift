//
//  ProfileView.swift
//  petadoptionapp
//
//  Created by STUDENT on 9/9/26.
//



import SwiftUI

struct ProfileView: View {
    @ObservedObject var controller: AppController
    @State private var selectedTab = 0
    
    var pageBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.systemBackground)
        case .system: return Color(hex: "#F9F6F0")
        }
    }

    var cardBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.secondarySystemGroupedBackground)
        case .system: return Color.white
        }
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                pageBackgroundColor.ignoresSafeArea()
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        
                        // Header Title + Settings Gear Button
                        HStack {
                            Text("My Profile")
                                .font(.system(size: 28, weight: .bold, design: .serif))
                                .foregroundColor(.primary)
                            Spacer()
                            NavigationLink(destination: SettingsView(controller: controller)) {
                                Image(systemName: "gearshape")
                                    .font(.title3)
                                    .padding(8)
                                    .background(cardBackgroundColor)
                                    .clipShape(Circle())
                                    .foregroundColor(.primary)
                            }
                        }
                        .padding(.horizontal)
                        
                        // Profile Info Card
                        VStack(spacing: 16) {
                            HStack(alignment: .top, spacing: 16) {
                                if let userImage = controller.user.uiImage {
                                    Image(uiImage: userImage)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 70, height: 70)
                                        .clipShape(Circle())
                                } else {
                                    Image(systemName: "person.crop.circle.fill")
                                        .resizable()
                                        .frame(width: 70, height: 70)
                                        .foregroundColor(.orange)
                                }
                               
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(controller.user.name)
                                        .font(.system(size: 20, weight: .bold, design: .serif))
                                        .foregroundColor(.primary)
                                    
                                    // Show "Edit your location" if location is empty
                                    if controller.user.location.isEmpty {
                                        Text("\(controller.user.handle) • Edit your location")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    } else {
                                        Text("\(controller.user.handle)\(controller.user.showLocation ? " • " + controller.user.location : "")")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                }
                                Spacer()
                            }
                            
                            // Show a placeholder bio if the user hasn't typed one yet
                            if controller.user.bio.isEmpty {
                                Text("Tap the settings gear to add a bio.")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary.opacity(0.6))
                                    .italic()
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            } else {
                                Text(controller.user.bio)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            
                            // Dynamic Metrics Row
                            HStack {
                                MetricBox(value: "\(controller.postedCount)", label: "Posted")
                                Divider().frame(height: 30)
                                MetricBox(value: "\(controller.adoptedPetsCount)", label: "Adopted")
                                Divider().frame(height: 30)
                                MetricBox(value: "\(controller.savedCount)", label: "Saved")
                            }
                            .padding(.top, 8)
                        }
                        .padding()
                        .background(cardBackgroundColor)
                        .cornerRadius(20)
                        .padding(.horizontal)
                        
                        // Segmented Tab Picker
                        HStack(spacing: 0) {
                            TabButton(title: "Posted", isSelected: selectedTab == 0, cardBg: cardBackgroundColor) { selectedTab = 0 }
                            TabButton(title: "Adopted", isSelected: selectedTab == 1, cardBg: cardBackgroundColor) { selectedTab = 1 }
                            TabButton(title: "Saved", isSelected: selectedTab == 2, cardBg: cardBackgroundColor) { selectedTab = 2 }
                        }
                        .padding(4)
                        .background(Color.gray.opacity(0.12))
                        .cornerRadius(16)
                        .padding(.horizontal)
                        
                        // Tab Content Views
                        if selectedTab == 0 {
                            let myPostedPets = controller.pets.filter { $0.posterName == controller.user.name && $0.status == .active }
                            
                            VStack(spacing: 12) {
                                if myPostedPets.isEmpty {
                                    EmptyStateView(title: "No active posts", subtitle: "Pets you post for adoption will show up here.", cardBg: cardBackgroundColor)
                                } else {
                                    ForEach(myPostedPets) { pet in
                                        ProfilePetRow(pet: pet, controller: controller, showAdoptedBtn: true, isAdoptedTab: false, cardBg: cardBackgroundColor)
                                    }
                                }
                            }
                            .padding(.horizontal)
                            
                        } else if selectedTab == 1 {
                            // Fetch pets where YOU are the adopter
                            let myAdoptedPets = controller.pets.filter { $0.adopterName == controller.user.name }
                            
                            VStack(spacing: 12) {
                                if myAdoptedPets.isEmpty {
                                    EmptyStateView(title: "No adopted pets yet", subtitle: "When you adopt a pet, they'll appear here.", cardBg: cardBackgroundColor)
                                } else {
                                    ForEach(myAdoptedPets) { pet in
                                        ProfilePetRow(pet: pet, controller: controller, showAdoptedBtn: false, isAdoptedTab: true, cardBg: cardBackgroundColor)
                                    }
                                    
                                    VStack(spacing: 8) {
                                        Image(systemName: "pawprint.fill")
                                            .foregroundColor(Color(hex: "#C8623A"))
                                        Text("\(controller.adoptedPetsCount) pets adopted")
                                            .font(.headline)
                                            .foregroundColor(.primary)
                                        Text("You've given them a loving home.")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(cardBackgroundColor)
                                    .cornerRadius(16)
                                    .padding(.top, 8)
                                }
                            }
                            .padding(.horizontal)
                            
                        } else {
                            let mySavedPets = controller.pets.filter { $0.isSaved }
                            
                            if mySavedPets.isEmpty {
                                EmptyStateView(title: "No saved pets", subtitle: "Tap the heart icon on any pet to save them for later.", cardBg: cardBackgroundColor)
                                    .padding(.horizontal)
                            } else {
                                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                                    ForEach(mySavedPets) { pet in
                                        SavedPetGridCard(pet: pet, controller: controller, cardBg: cardBackgroundColor)
                                    }
                                }
                                .padding(.horizontal)
                            }
                        }
                    }
                    .padding(.vertical)
                    .padding(.bottom, 90)
                }
            }
        }
    }
}

// MARK: - Reusable Helper Components
struct EmptyStateView: View {
    let title: String
    let subtitle: String
    var cardBg: Color = Color.white
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: "pawprint")
                .font(.title)
                .foregroundColor(.gray.opacity(0.5))
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)
            Text(subtitle)
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(30)
        .frame(maxWidth: .infinity)
        .background(cardBg)
        .cornerRadius(16)
    }
}

struct MetricBox: View {
    let value: String
    let label: String
    
    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.headline)
                .foregroundColor(.primary)
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

struct TabButton: View {
    let title: String
    let isSelected: Bool
    var cardBg: Color = Color.white
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline.weight(.semibold))
                .foregroundColor(isSelected ? .white : .primary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(isSelected ? Color(hex: "#C8623A") : cardBg)
                .cornerRadius(12)
        }
    }
}

struct ProfilePetRow: View {
    let pet: Pet
    @ObservedObject var controller: AppController
    let showAdoptedBtn: Bool
    var isAdoptedTab: Bool = false
    var cardBg: Color = Color.white
    
    var body: some View {
        HStack(spacing: 12) {
            if let uiImage = pet.uiImage {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 72, height: 72)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            } else {
                Rectangle()
                    .fill(Color.orange.opacity(0.2))
                    .frame(width: 72, height: 72)
                    .overlay(
                        Image(systemName: "pawprint.circle.fill")
                            .foregroundColor(Color(hex: "#C8623A"))
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(pet.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                Text("\(pet.breed) • \(pet.age)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                HStack(spacing: 6) {
                    Image(systemName: "mappin.and.ellipse")
                    Text(pet.location)
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
            Spacer()
            
            if showAdoptedBtn && pet.status == .active {
                Button("Mark Adopted") {
                    withAnimation {
                        controller.markAsAdopted(pet: pet)
                    }
                }
                .font(.caption)
                .bold()
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.green.opacity(0.15))
                .foregroundColor(.green)
                .cornerRadius(8)
            } else if isAdoptedTab {
                Button("Remove") {
                    withAnimation {
                        controller.removeAdoption(pet: pet)
                    }
                }
                .font(.caption)
                .bold()
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.red.opacity(0.1))
                .foregroundColor(.red)
                .cornerRadius(8)
            }
        }
        .padding()
        .background(cardBg)
        .cornerRadius(16)
    }
}

struct SavedPetGridCard: View {
    let pet: Pet
    @ObservedObject var controller: AppController
    var cardBg: Color = Color.white
    
    var body: some View {
        VStack(spacing: 8) {
            ZStack(alignment: .topTrailing) {
                if let uiImage = pet.uiImage {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(height: 120)
                        .frame(maxWidth: .infinity)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                } else {
                    Rectangle()
                        .fill(Color.orange.opacity(0.2))
                        .frame(height: 120)
                        .overlay(
                            Image(systemName: "pawprint.circle.fill")
                                .font(.title)
                                .foregroundColor(Color(hex: "#C8623A"))
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                
                Button(action: {
                    withAnimation {
                        controller.toggleSave(for: pet)
                    }
                }) {
                    Image(systemName: pet.isSaved ? "heart.fill" : "heart")
                        .foregroundColor(pet.isSaved ? Color(hex: "#C8623A") : .gray)
                        .padding(8)
                        .background(cardBg.opacity(0.9))
                        .clipShape(Circle())
                }
                .padding(8)
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(pet.name)
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(.primary)
                Text(pet.breed)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(8)
        .background(cardBg)
        .cornerRadius(14)
    }
}
