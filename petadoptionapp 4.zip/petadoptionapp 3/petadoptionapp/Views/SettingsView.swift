//
//  SettingsView.swift
//  petadoptionapp
//
//  Created by STUDENT on 9/9/26.
//

//
//  SettingsView.swift
//  petadoptionapp
//

import SwiftUI
import PhotosUI

struct SettingsView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var controller: AppController
    @Environment(\.colorScheme) var colorScheme
    
    @State private var adoptionRequests = true
    @State private var showDeleteAlert = false
    
    var backgroundColor: Color {
        if controller.selectedTheme == .dark || colorScheme == .dark {
            return Color(UIColor.systemBackground)
        } else {
            return Color(hex: "#F9F6F0")
        }
    }
    
    var cardBackgroundColor: Color {
        if controller.selectedTheme == .dark || colorScheme == .dark {
            return Color(UIColor.secondarySystemGroupedBackground)
        } else {
            return Color.white
        }
    }
    
    var body: some View {
        ZStack {
            backgroundColor.ignoresSafeArea()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    HStack(spacing: 16) {
                        Button(action: { dismiss() }) {
                            Image(systemName: "chevron.left")
                                .padding(10)
                                .background(cardBackgroundColor)
                                .clipShape(Circle())
                                .foregroundColor(.primary)
                        }
                        Text("Settings")
                            .font(.system(size: 24, weight: .bold, design: .serif))
                            .foregroundColor(.primary)
                    }
                    .padding(.horizontal)
                    
                    // APPEARANCE
                    SectionHeader(title: "APPEARANCE")
                    VStack(spacing: 0) {
                        ForEach(Array(AppTheme.allCases.enumerated()), id: \.element.id) { index, theme in
                            Button(action: {
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    controller.selectedTheme = theme
                                }
                            }) {
                                HStack(spacing: 14) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 8)
                                            .fill(controller.selectedTheme == theme ? Color(hex: "#C8623A").opacity(0.12) : Color.gray.opacity(0.12))
                                            .frame(width: 32, height: 32)
                                        Image(systemName: theme.iconName)
                                            .font(.system(size: 15, weight: .medium))
                                            .foregroundColor(controller.selectedTheme == theme ? Color(hex: "#C8623A") : .primary)
                                    }
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(theme.rawValue).font(.subheadline).fontWeight(.semibold).foregroundColor(.primary)
                                        Text(theme.subtitle).font(.caption).foregroundColor(.secondary)
                                    }
                                    Spacer()
                                    Image(systemName: controller.selectedTheme == theme ? "checkmark.circle.fill" : "circle")
                                        .font(.title3)
                                        .foregroundColor(controller.selectedTheme == theme ? Color(hex: "#C8623A") : Color.gray.opacity(0.4))
                                }
                                .padding(.vertical, 14)
                                .padding(.horizontal, 16)
                                .background(controller.selectedTheme == theme ? Color(hex: "#C8623A").opacity(0.06) : Color.clear)
                            }
                            if index < AppTheme.allCases.count - 1 {
                                Divider().padding(.leading, 62)
                            }
                        }
                    }
                    .background(cardBackgroundColor)
                    .cornerRadius(16)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.gray.opacity(0.15), lineWidth: 1))
                    .padding(.horizontal)
                    
                    // ACCOUNT
                    SectionHeader(title: "ACCOUNT")
                    VStack(spacing: 12) {
                        NavigationLink(destination: EditProfileView(controller: controller)) {
                            SettingsRow(icon: "person", title: "Edit Profile", subtitle: "Update your name, photo, and bio", iconBg: .orange.opacity(0.15), cardBg: cardBackgroundColor)
                        }
                        .buttonStyle(PlainButtonStyle())
                        NavigationLink(destination: ChangePasswordView(controller: controller)) {
                            SettingsRow(icon: "lock", title: "Change Password", subtitle: "Update your login credentials", iconBg: .green.opacity(0.15), cardBg: cardBackgroundColor)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    .padding(.horizontal)
                    
                    // NOTIFICATIONS
                    SectionHeader(title: "NOTIFICATIONS")
                    VStack(spacing: 12) {
                        ToggleRow(title: "Adoption Requests", subtitle: "When someone requests your pet", isOn: $adoptionRequests, cardBg: cardBackgroundColor)
                        ToggleRow(title: "Pet Updates", subtitle: "Status changes on pets you've saved", isOn: $controller.petUpdatesEnabled, cardBg: cardBackgroundColor)
                            .onChange(of: controller.petUpdatesEnabled) { _ in
                                controller.save()
                            }
                    }
                    .padding(.horizontal)
                    
                    // PRIVACY
                    SectionHeader(title: "PRIVACY")
                    VStack(spacing: 12) {
                        ToggleRow(title: "Show Location", subtitle: "Display city on your public profile", isOn: $controller.user.showLocation, cardBg: cardBackgroundColor)
                            .onChange(of: controller.user.showLocation) { _ in
                                controller.save()
                            }
                    }
                    .padding(.horizontal)
                    
                    // DATA
                    SectionHeader(title: "DATA")
                    VStack(spacing: 12) {
                        // Log Out Button
                        Button(action: { controller.logout() }) {
                            HStack(spacing: 16) {
                                Image(systemName: "rectangle.portrait.and.arrow.right")
                                    .foregroundColor(.white)
                                    .frame(width: 36, height: 36)
                                    .background(Color.orange)
                                    .clipShape(Circle())
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Log Out").font(.subheadline).bold().foregroundColor(.primary)
                                    Text("Sign out of your account").font(.caption).foregroundColor(.secondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundColor(.gray)
                            }
                            .padding()
                            .background(cardBackgroundColor)
                            .cornerRadius(16)
                        }
                        
                        // Delete Data Button
                        Button(action: { showDeleteAlert = true }) {
                            HStack(spacing: 16) {
                                Image(systemName: "trash")
                                    .foregroundColor(.white)
                                    .frame(width: 36, height: 36)
                                    .background(Color.red)
                                    .clipShape(Circle())
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Delete All Data").font(.subheadline).bold().foregroundColor(.red)
                                    Text("Clear all saved pets, profile, and settings").font(.caption).foregroundColor(.secondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundColor(.gray)
                            }
                            .padding()
                            .background(cardBackgroundColor)
                            .cornerRadius(16)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
        }
        .navigationBarBackButtonHidden(true)
        .alert("Delete All Data?", isPresented: $showDeleteAlert) {
            Button("Cancel", role: .cancel) { }
            Button("Delete", role: .destructive) {
                controller.deleteAllData()
            }
        } message: {
            Text("This will permanently remove all your saved pets, profile changes, and preferences, and restore the app to its initial state. This action cannot be undone.")
        }
    }
}

// MARK: - Reusable UI Components

struct SectionHeader: View {
    let title: String
    var body: some View {
        Text(title)
            .font(.caption)
            .fontWeight(.bold)
            .foregroundColor(.secondary)
            .padding(.horizontal)
    }
}

struct SettingsRow: View {
    let icon: String
    let title: String
    let subtitle: String
    let iconBg: Color
    var cardBg: Color = Color.white
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .foregroundColor(.primary)
                .frame(width: 36, height: 36)
                .background(iconBg)
                .clipShape(Circle())
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline).bold().foregroundColor(.primary)
                Text(subtitle).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right").font(.caption).foregroundColor(.gray)
        }
        .padding()
        .background(cardBg)
        .cornerRadius(16)
    }
}

struct ToggleRow: View {
    let title: String
    let subtitle: String
    @Binding var isOn: Bool
    var cardBg: Color = Color.white
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline).bold().foregroundColor(.primary)
                Text(subtitle).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            Toggle("", isOn: $isOn)
                .tint(Color(hex: "#C8623A"))
                .labelsHidden()
        }
        .padding()
        .background(cardBg)
        .cornerRadius(16)
    }
}

// MARK: - Edit Profile View

struct EditProfileView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var controller: AppController
    
    @State private var name: String = ""
    @State private var location: String = ""
    @State private var bio: String = ""
    @State private var showSavedAlert = false
    
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var selectedImage: UIImage? = nil
    
    var pageBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.systemBackground)
        case .system: return Color(hex: "#F9F6F0")
        }
    }
    
    var cardBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.secondarySystemGroupedBackground)
        case .system: return Color.white
        }
    }
    
    var body: some View {
        ZStack {
            pageBackgroundColor.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    HStack(spacing: 16) {
                        Button(action: { dismiss() }) {
                            Image(systemName: "chevron.left")
                                .padding(10)
                                .background(cardBackgroundColor)
                                .clipShape(Circle())
                                .foregroundColor(.primary)
                        }
                        Text("Edit Profile")
                            .font(.system(size: 24, weight: .bold, design: .serif))
                            .foregroundColor(.primary)
                    }
                    .padding(.horizontal)
                    
                    VStack(spacing: 16) {
                        VStack(spacing: 10) {
                            if let selectedImage = selectedImage {
                                Image(uiImage: selectedImage)
                                    .resizable().scaledToFill()
                                    .frame(width: 90, height: 90).clipShape(Circle())
                            } else if let existingImage = controller.user.uiImage {
                                Image(uiImage: existingImage)
                                    .resizable().scaledToFill()
                                    .frame(width: 90, height: 90).clipShape(Circle())
                            } else {
                                Image(systemName: "person.crop.circle.fill")
                                    .resizable().frame(width: 90, height: 90).foregroundColor(.orange)
                            }
                            PhotosPicker(selection: $selectedItem, matching: .images) {
                                Text("Change Profile Photo")
                                    .font(.subheadline).fontWeight(.semibold)
                                    .foregroundColor(Color(hex: "#C8623A"))
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .onChange(of: selectedItem) { newItem in
                            Task {
                                if let data = try? await newItem?.loadTransferable(type: Data.self),
                                   let uiImage = UIImage(data: data) {
                                    selectedImage = uiImage
                                    controller.updateProfileImage(uiImage)
                                }
                            }
                        }
                        
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Full Name").font(.caption).bold().foregroundColor(.secondary)
                            TextField("Enter your name", text: $name)
                                .padding()
                                .background(cardBackgroundColor)
                                .cornerRadius(12)
                                .foregroundColor(.primary)
                        }
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Location").font(.caption).bold().foregroundColor(.secondary)
                            TextField("Enter your location", text: $location)
                                .padding()
                                .background(cardBackgroundColor)
                                .cornerRadius(12)
                                .foregroundColor(.primary)
                        }
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Bio").font(.caption).bold().foregroundColor(.secondary)
                            ZStack(alignment: .topLeading) {
                                if bio.isEmpty {
                                    Text("Tell us about yourself...")
                                        .font(.subheadline)
                                        .foregroundColor(.gray.opacity(0.5))
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 16)
                                }
                                TextEditor(text: $bio)
                                    .frame(height: 100)
                                    .padding(8)
                                    .scrollContentBackground(.hidden)
                                    .background(cardBackgroundColor)
                                    .cornerRadius(12)
                                    .foregroundColor(.primary)
                            }
                        }
                        Button(action: saveChanges) {
                            Text("Save Changes")
                                .font(.headline).foregroundColor(.white)
                                .frame(maxWidth: .infinity).padding()
                                .background(Color(hex: "#C8623A")).cornerRadius(14)
                        }
                        .padding(.top, 10)
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            name = controller.user.name
            location = controller.user.location
            bio = controller.user.bio
            selectedImage = controller.user.uiImage
        }
        .alert("Profile Updated", isPresented: $showSavedAlert) {
            Button("OK", role: .cancel) { dismiss() }
        } message: {
            Text("Your profile information has been saved successfully.")
        }
    }
    
    private func saveChanges() {
        controller.updateProfile(name: name, bio: bio, location: location)
        showSavedAlert = true
    }
}

// MARK: - Change Password View

struct ChangePasswordView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var controller: AppController
    @State private var currentPassword = ""
    @State private var newPassword = ""
    @State private var confirmPassword = ""
    @State private var alertMessage = ""
    @State private var showAlert = false
    
    var pageBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.systemBackground)
        case .system: return Color(hex: "#F9F6F0")
        }
    }
    var cardBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.secondarySystemGroupedBackground)
        case .system: return Color.white
        }
    }
    
    var body: some View {
        ZStack {
            pageBackgroundColor.ignoresSafeArea()
            VStack(alignment: .leading, spacing: 20) {
                HStack(spacing: 16) {
                    Button(action: { dismiss() }) {
                        Image(systemName: "chevron.left")
                            .padding(10).background(cardBackgroundColor)
                            .clipShape(Circle()).foregroundColor(.primary)
                    }
                    Text("Change Password")
                        .font(.system(size: 24, weight: .bold, design: .serif))
                        .foregroundColor(.primary)
                }
                .padding(.horizontal)
                
                VStack(spacing: 16) {
                    SecureField("Current Password", text: $currentPassword)
                        .padding().background(cardBackgroundColor).cornerRadius(12).foregroundColor(.primary)
                    SecureField("New Password", text: $newPassword)
                        .padding().background(cardBackgroundColor).cornerRadius(12).foregroundColor(.primary)
                    SecureField("Confirm New Password", text: $confirmPassword)
                        .padding().background(cardBackgroundColor).cornerRadius(12).foregroundColor(.primary)
                    Button(action: updatePassword) {
                        Text("Update Password")
                            .font(.headline).foregroundColor(.white)
                            .frame(maxWidth: .infinity).padding()
                            .background(Color(hex: "#C8623A")).cornerRadius(14)
                    }
                    .padding(.top, 10)
                }
                .padding(.horizontal)
                Spacer()
            }
            .padding(.vertical)
        }
        .navigationBarBackButtonHidden(true)
        .alert("Notice", isPresented: $showAlert) {
            Button("OK", role: .cancel) {
                if alertMessage == "Password updated successfully!" { dismiss() }
            }
        } message: { Text(alertMessage) }
    }
    
    private func updatePassword() {
        guard !currentPassword.isEmpty, !newPassword.isEmpty, !confirmPassword.isEmpty else {
            alertMessage = "Please fill in all password fields."
            showAlert = true
            return
        }
        
        // Check if current password matches the locally saved password
        guard currentPassword == controller.user.password else {
            alertMessage = "Current password is incorrect."
            showAlert = true
            return
        }
        
        guard newPassword == confirmPassword else {
            alertMessage = "New passwords do not match."
            showAlert = true
            return
        }
        
        // Save the new password to local storage
        controller.user.password = newPassword
        controller.save()
        
        alertMessage = "Password updated successfully!"
        showAlert = true
    }
}
