//
//  EditPetView.swift
//  petadoptionapp
//
//  Created by STUDENT on 11/18/26.
//


import SwiftUI

struct EditPetView: View {
    @ObservedObject var controller: AppController
    @Environment(\.dismiss) var dismiss
    
    let pet: Pet
    
    @State private var age: String
    @State private var location: String
    @State private var bio: String
    
    init(pet: Pet, controller: AppController) {
        self.pet = pet
        self.controller = controller
        _age = State(initialValue: pet.age)
        _location = State(initialValue: pet.location)
        _bio = State(initialValue: pet.bio)
    }
    
    var pageBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.systemBackground)
        case .system: return Color(hex: "#F9F6F0")
        }
    }
    
    var cardBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.secondarySystemGroupedBackground)
        case .system: return Color.white
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                pageBackgroundColor.ignoresSafeArea()
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Text("Update the details of your pet post. This will immediately update the Discover feed.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .padding(.horizontal)
                        
                        VStack(alignment: .leading, spacing: 16) {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Age").font(.caption).bold().foregroundColor(.secondary)
                                TextField("Age", text: $age)
                                    .padding()
                                    .background(cardBackgroundColor)
                                    .cornerRadius(12)
                                    .foregroundColor(.primary)
                            }
                            
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Location").font(.caption).bold().foregroundColor(.secondary)
                                TextField("Location", text: $location)
                                    .padding()
                                    .background(cardBackgroundColor)
                                    .cornerRadius(12)
                                    .foregroundColor(.primary)
                            }
                            
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Bio / Description").font(.caption).bold().foregroundColor(.secondary)
                                TextEditor(text: $bio)
                                    .frame(height: 120)
                                    .padding(8)
                                    .scrollContentBackground(.hidden)
                                    .background(cardBackgroundColor)
                                    .cornerRadius(12)
                                    .foregroundColor(.primary)
                            }
                        }
                        .padding(.horizontal)
                        
                        Button(action: {
                            controller.updatePet(petID: pet.id, newAge: age, newLocation: location, newBio: bio)
                            dismiss()
                        }) {
                            Text("Save Changes")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color(hex: "#C8623A"))
                                .cornerRadius(14)
                        }
                        .padding(.horizontal)
                        .padding(.top, 10)
                    }
                    .padding(.vertical)
                }
            }
            .navigationTitle("Edit \(pet.name)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }
}
