//
//  DiscoverView.swift
//  petadoptionapp
//
//  Created by STUDENT on 9/9/26.
//


import SwiftUI

struct DiscoverView: View {
    @ObservedObject var controller: AppController
    @Binding var selectedTab: Int
    @Environment(\.colorScheme) var systemColorScheme
    @State private var searchText = ""
    
    var pageBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.systemBackground)
        case .system: return Color(hex: "#F9F6F0")
        }
    }

    var cardBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.secondarySystemGroupedBackground)
        case .system: return Color.white
        }
    }
    
    var filteredPets: [Pet] {
        controller.pets.filter { pet in
            let matchesCategory = controller.selectedCategory == "All" ||
                                  pet.category.lowercased() == controller.selectedCategory.lowercased()
            
            if searchText.isEmpty {
                return matchesCategory
            } else {
                let query = searchText.lowercased()
                let matchesSearch = pet.name.lowercased().contains(query) ||
                                    pet.breed.lowercased().contains(query) ||
                                    pet.location.lowercased().contains(query)
                return matchesCategory && matchesSearch
            }
        }
    }
    
    var body: some View {
        ZStack {
            pageBackgroundColor.ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("FIND A FRIEND")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.secondary)
                            
                            Text("Pets Near You")
                                .font(.system(size: 28, weight: .bold, design: .serif))
                                .foregroundColor(.primary)
                        }
                        Spacer()
                        
                        if let userImage = controller.user.uiImage {
                            Image(uiImage: userImage)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 40, height: 40)
                                .clipShape(Circle())
                        } else {
                            Image(systemName: "person.crop.circle.fill")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.orange)
                        }
                    }
                    .padding(.horizontal)
                    
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        TextField("Search by name, breed, city...", text: $searchText)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                            .foregroundColor(.primary)
                        
                        if !searchText.isEmpty {
                            Button(action: { searchText = "" }) {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding()
                    .background(cardBackgroundColor)
                    .cornerRadius(16)
                    .padding(.horizontal)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(controller.categories, id: \.self) { category in
                                Button(action: { controller.selectedCategory = category }) {
                                    Text(category)
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                        .padding(.horizontal, 20)
                                        .padding(.vertical, 10)
                                        .background(controller.selectedCategory == category ? Color(hex: "#C8623A") : cardBackgroundColor)
                                        .foregroundColor(controller.selectedCategory == category ? .white : .primary)
                                        .cornerRadius(20)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    Text("\(filteredPets.count) pets available")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                    
                    VStack(spacing: 20) {
                        if filteredPets.isEmpty {
                            VStack(spacing: 8) {
                                Image(systemName: "pawprint.fill")
                                    .font(.largeTitle)
                                    .foregroundColor(.gray.opacity(0.4))
                                Text("No pets found matching your criteria.")
                                    .font(.headline)
                                    .foregroundColor(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.top, 40)
                        } else {
                            ForEach(filteredPets) { pet in
                                NavigationLink(destination: PetDetailView(pet: pet, controller: controller, selectedTab: $selectedTab)) {
                                    DiscoverPetCard(pet: pet, controller: controller, cardBg: cardBackgroundColor)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
                .padding(.bottom, 90)
            }
        }
    }
}

struct DiscoverPetCard: View {
    let pet: Pet
    @ObservedObject var controller: AppController
    var cardBg: Color = Color.white
    
    @State private var showSavedAlert = false
    @State private var showDeleteAlert = false
    @State private var showEditSheet = false // State for edit sheet
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            
            ZStack(alignment: .topTrailing) {
                if let uiImage = pet.uiImage {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(height: 220)
                        .frame(maxWidth: .infinity)
                        .clipped()
                } else {
                    Rectangle()
                        .fill(Color.orange.opacity(0.15))
                        .frame(height: 220)
                        .overlay(
                            Image(systemName: "pawprint.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(Color(hex: "#C8623A").opacity(0.6))
                        )
                }
                
                HStack(spacing: 8) {
                    Text(pet.category.hasSuffix("s") ? String(pet.category.dropLast()) : pet.category)
                        .font(.caption)
                        .bold()
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(cardBg)
                        .foregroundColor(.primary)
                        .cornerRadius(12)
                    
                    Spacer()
                    
                    // Edit Button (Only for original poster)
                    if pet.posterName == controller.user.name {
                        Button(action: { showEditSheet = true }) {
                            Image(systemName: "pencil")
                                .foregroundColor(Color(hex: "#C8623A"))
                                .padding(10)
                                .background(cardBg)
                                .clipShape(Circle())
                        }
                    }
                    
                    // Delete / Un-Adopt Button
                    if (pet.posterName == controller.user.name && pet.status == .active) ||
                       (pet.adopterName == controller.user.name) {
                        Button(action: { showDeleteAlert = true }) {
                            Image(systemName: "trash.fill")
                                .foregroundColor(.red)
                                .padding(10)
                                .background(cardBg)
                                .clipShape(Circle())
                        }
                    }
                    
                    // Favorite Button
                    Button(action: {
                        let wasSaved = pet.isSaved
                        withAnimation {
                            controller.toggleSave(for: pet)
                        }
                        if controller.petUpdatesEnabled && !wasSaved {
                            showSavedAlert = true
                        }
                    }) {
                        Image(systemName: pet.isSaved ? "heart.fill" : "heart")
                            .foregroundColor(pet.isSaved ? Color(hex: "#C8623A") : .gray)
                            .padding(10)
                            .background(cardBg)
                            .clipShape(Circle())
                    }
                }
                .padding(12)
            }
            .clipShape(CustomCorners(corners: [.topLeft, .topRight], radius: 20))
            
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text(pet.name)
                        .font(.system(size: 22, weight: .bold, design: .serif))
                        .foregroundColor(.primary)
                    Spacer()
                    
                    if pet.status == .adopted {
                        Text("Adopted")
                            .font(.caption)
                            .bold()
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(Color.green.opacity(0.15))
                            .foregroundColor(.green)
                            .cornerRadius(10)
                    } else {
                        Text(pet.gender)
                            .font(.caption)
                            .bold()
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(Color.teal.opacity(0.12))
                            .foregroundColor(.teal)
                            .cornerRadius(10)
                    }
                }
                
                Text("\(pet.breed)\n\(pet.age)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                HStack(spacing: 4) {
                    Image(systemName: "mappin.and.ellipse")
                    Text(pet.location)
                }
                .font(.caption)
                .foregroundColor(.secondary)
                
                HStack(spacing: 8) {
                    ForEach(pet.tags, id: \.self) { tag in
                        Text(tag)
                            .font(.caption2)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Color.gray.opacity(0.12))
                            .foregroundColor(.primary)
                            .cornerRadius(8)
                    }
                }
                
                Divider().padding(.vertical, 4)
                
                HStack {
                    HStack(spacing: 4) {
                        Image(systemName: "heart.fill")
                            .foregroundColor(Color(hex: "#C8623A"))
                        Text("\(pet.likesCount)")
                            .foregroundColor(.primary)
                    }
                    .font(.caption)
                }
            }
            .padding(16)
            .background(cardBg)
            .clipShape(CustomCorners(corners: [.bottomLeft, .bottomRight], radius: 20))
        }
        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
        .sheet(isPresented: $showEditSheet) {
            EditPetView(pet: pet, controller: controller)
                .preferredColorScheme(controller.selectedTheme.colorScheme)
        }
        .alert("Notification", isPresented: $showSavedAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("Saved successfully")
        }
        .alert("Delete Post", isPresented: $showDeleteAlert) {
            Button("Cancel", role: .cancel) { }
            Button("Delete", role: .destructive) {
                withAnimation {
                    controller.deletePet(pet: pet)
                }
            }
        } message: {
            Text(pet.adopterName == controller.user.name && pet.posterName != controller.user.name ?
                 "Are you sure you want to remove this adoption? The pet will be returned to the discover feed." :
                 "Are you sure you want to delete \(pet.name)? This action cannot be undone.")
        }
    }
}
