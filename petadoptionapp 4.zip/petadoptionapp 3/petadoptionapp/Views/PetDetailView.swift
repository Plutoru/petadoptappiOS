//
//  PetDetailView.swift
//  petadoptionapp
//
//  Created by STUDENT on 9/11/26.
//

import SwiftUI

struct PetDetailView: View {
    let pet: Pet
    @ObservedObject var controller: AppController
    @Binding var selectedTab: Int
    @Environment(\.dismiss) private var dismiss
    
    @State private var showAdoptAlert = false

    // Dynamic Theme Colors
    var pageBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.systemBackground)
        case .system: return Color(hex: "#F9F6F0")
        }
    }
    
    var cardBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.secondarySystemGroupedBackground)
        case .system: return Color.white
        }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            pageBackgroundColor.ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    
                    // Image Header
                    ZStack(alignment: .topLeading) {
                        if let uiImage = pet.uiImage {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFill()
                                .frame(height: 300)
                                .frame(maxWidth: .infinity)
                                .clipped()
                        } else {
                            Rectangle()
                                .fill(Color.orange.opacity(0.2))
                                .frame(height: 300)
                                .overlay(
                                    Image(systemName: "pawprint.circle.fill")
                                        .font(.system(size: 80))
                                        .foregroundColor(Color(hex: "#C8623A").opacity(0.6))
                                )
                        }
                        
                        Button(action: { dismiss() }) {
                            Image(systemName: "chevron.left")
                                .bold()
                                .foregroundColor(.primary)
                                .padding(12)
                                .background(cardBackgroundColor)
                                .clipShape(Circle())
                        }
                        .padding(.top, 50)
                        .padding(.leading, 16)
                    }
                    
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Text(pet.name)
                                .font(.system(size: 32, weight: .bold, design: .serif))
                                .foregroundColor(.primary)
                            Spacer()
                            Text(pet.gender)
                                .font(.callout)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(Color.teal.opacity(0.12))
                                .foregroundColor(.teal)
                                .cornerRadius(12)
                        }
                        
                        Text("\(pet.breed)\n\(pet.age)")
                            .font(.title3)
                            .foregroundColor(.secondary)
                        
                        // Dynamic Location (Matches what user inputted)
                        HStack {
                            Image(systemName: "mappin.and.ellipse")
                            Text(pet.location)
                        }
                        .foregroundColor(.secondary)
                        
                        Divider().padding(.vertical, 8)
                        
                        Text("About Me")
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        // Dynamic Bio (Matches what user typed)
                        Text(pet.bio)
                            .foregroundColor(.secondary)
                            .lineSpacing(4)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 100)
                }
            }
            
            // Fixed Bottom Action Bar
            HStack {
                Button(action: { controller.toggleSave(for: pet) }) {
                    Image(systemName: pet.isSaved ? "heart.fill" : "heart")
                        .font(.title2)
                        .foregroundColor(pet.isSaved ? Color(hex: "#C8623A") : .gray)
                        .frame(width: 50, height: 50)
                        .background(controller.selectedTheme == .dark ? Color(UIColor.tertiarySystemGroupedBackground) : Color(hex: "#F3EFEA"))
                        .cornerRadius(14)
                }
                
                Button(action: { showAdoptAlert = true }) {
                    Text("Adopt \(pet.name)")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(Color(hex: "#C8623A"))
                        .cornerRadius(14)
                }
            }
            .padding()
            .background(cardBackgroundColor.ignoresSafeArea(edges: .bottom))
        }
        .navigationBarBackButtonHidden(true)
        .alert("Adopt \(pet.name)", isPresented: $showAdoptAlert) {
            Button("Cancel", role: .cancel) { }
            Button("Adopt", role: .none) {
                controller.adoptPet(pet: pet)
                dismiss()
                selectedTab = 1 // Switch to Profile Tab
            }
        } message: {
            Text("Are you sure you want to adopt \(pet.name)? This pet will be added to your profile's adopted list.")
        }
    }
}
