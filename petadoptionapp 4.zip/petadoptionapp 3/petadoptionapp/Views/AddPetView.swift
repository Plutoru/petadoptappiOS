//
//  AddPetView.swift
//  petadoptionapp
//
//  Created by STUDENT on 9/9/26.
//

//
//  AddPetView.swift
//  petadoptionapp
//

import SwiftUI
import PhotosUI

struct AddPetView: View {
    @ObservedObject var controller: AppController
    @Binding var isPresented: Bool
    
    @State private var currentStep = 1
    @State private var showPostAlert = false
    
    // Photo Picker States
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var selectedImage: UIImage? = nil
    
    // Dynamic Theme Colors
    var pageBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.systemBackground)
        case .system: return Color(hex: "#F9F6F0")
        }
    }
    
    var cardBackgroundColor: Color {
        switch controller.selectedTheme {
        case .dark: return Color(UIColor.secondarySystemGroupedBackground)
        case .system: return Color.white
        }
    }
    
    // Step 1 Form Fields
    @State private var petName: String = ""
    @State private var selectedSpecies: String = "Dog"
    @State private var breed: String = ""
    @State private var selectedGender: String = "Male"
    @State private var selectedAge: String = "1–3 years"
    @State private var selectedSize: String = "Medium"
    @State private var location: String = ""
    
    // Step 2 Form Fields
    @State private var isVaccinated: Bool = false
    @State private var isSpayedNeutered: Bool = false
    @State private var isGoodWithKids: Bool = false
    @State private var isGoodWithPets: Bool = false
    
    // Step 3 Form Fields
    @State private var storyDescription: String = ""
    
    let speciesList = [
        ("🐶", "Dog"),
        ("🐱", "Cat"),
        ("🐰", "Rabbit"),
        ("🦜", "Bird"),
        ("🐾", "Other")
    ]
    
    let ageRanges = ["< 3 months", "3–12 months", "1–3 years", "3–7 years", "7+ years"]
    let sizeList = ["Small", "Medium", "Large"]
    
    var displayName: String {
        petName.trimmingCharacters(in: .whitespaces).isEmpty ? "New Pet" : petName
    }
    
    var body: some View {
        ZStack {
            pageBackgroundColor.ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("HELP THEM FIND A HOME")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(.secondary)
                        
                        Text("Post a Pet")
                            .font(.system(size: 28, weight: .bold, design: .serif))
                            .foregroundColor(.primary)
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 8) {
                            ForEach(1...3, id: \.self) { step in
                                Rectangle()
                                    .fill(step <= currentStep ? Color(hex: "#C8623A") : Color.gray.opacity(0.3))
                                    .frame(height: 4)
                                    .cornerRadius(2)
                            }
                        }
                        
                        Text(stepSubtitle)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.horizontal)
                    
                    if currentStep == 1 {
                        stepOneView
                    } else if currentStep == 2 {
                        stepTwoView
                    } else {
                        stepThreeView
                    }
                }
                .padding(.vertical)
                .padding(.bottom, 80)
            }
        }
        .alert("Confirm Post", isPresented: $showPostAlert) {
            Button("Cancel", role: .cancel) { }
            Button("Yes", role: .none) {
                submitPet()
            }
        } message: {
            Text("Are you sure you want to post this? It cannot be undone or edited once you click yes.")
        }
    }
    
    private var stepSubtitle: String {
        switch currentStep {
        case 1: return "Step 1 of 3 — Basic Info"
        case 2: return "Step 2 of 3 — Health & Details"
        default: return "Step 3 of 3 — Photos & Story"
        }
    }
    
    private var stepOneView: some View {
        VStack(alignment: .leading, spacing: 18) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Pet's Name")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                TextField("e.g. Mango", text: $petName)
                    .padding()
                    .background(cardBackgroundColor)
                    .cornerRadius(12)
                    .foregroundColor(.primary)
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Species")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(speciesList, id: \.1) { emoji, species in
                            Button(action: { selectedSpecies = species }) {
                                HStack(spacing: 6) {
                                    Text(emoji)
                                    Text(species)
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                }
                                .padding(.horizontal, 16)
                                .padding(.vertical, 10)
                                .background(cardBackgroundColor)
                                .foregroundColor(selectedSpecies == species ? Color(hex: "#C8623A") : .secondary)
                                .cornerRadius(16)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(selectedSpecies == species ? Color(hex: "#C8623A") : Color.clear, lineWidth: 1.5)
                                )
                            }
                        }
                    }
                }
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Breed")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                TextField("e.g. Golden Retriever, Mixed", text: $breed)
                    .padding()
                    .background(cardBackgroundColor)
                    .cornerRadius(12)
                    .foregroundColor(.primary)
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Gender")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                HStack(spacing: 12) {
                    GenderButton(title: "♂ Male", isSelected: selectedGender == "Male", cardBg: cardBackgroundColor) {
                        selectedGender = "Male"
                    }
                    GenderButton(title: "♀ Female", isSelected: selectedGender == "Female", cardBg: cardBackgroundColor) {
                        selectedGender = "Female"
                    }
                }
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Age")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 8) {
                        ForEach(ageRanges.prefix(3), id: \.self) { age in
                            SelectionPill(title: age, isSelected: selectedAge == age, cardBg: cardBackgroundColor) {
                                selectedAge = age
                            }
                        }
                    }
                    HStack(spacing: 8) {
                        ForEach(ageRanges.suffix(2), id: \.self) { age in
                            SelectionPill(title: age, isSelected: selectedAge == age, cardBg: cardBackgroundColor) {
                                selectedAge = age
                            }
                        }
                    }
                }
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Size")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                HStack(spacing: 12) {
                    ForEach(sizeList, id: \.self) { size in
                        SelectionPill(title: size, isSelected: selectedSize == size, cardBg: cardBackgroundColor) {
                            selectedSize = size
                        }
                    }
                }
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Location")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                TextField("City, State", text: $location)
                    .padding()
                    .background(cardBackgroundColor)
                    .cornerRadius(12)
                    .foregroundColor(.primary)
            }
            
            Button(action: { withAnimation { currentStep = 2 } }) {
                Text("Continue")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(hex: "#C8623A"))
                    .cornerRadius(16)
            }
            .padding(.top, 8)
        }
        .padding(.horizontal)
    }
    
    private var stepTwoView: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Check all that apply for \(displayName):")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            VStack(spacing: 12) {
                DetailCheckCard(title: "Vaccinated", subtitle: "Up to date on core vaccinations", isChecked: $isVaccinated, cardBg: cardBackgroundColor)
                DetailCheckCard(title: "Spayed / Neutered", subtitle: "Already spayed or neutered", isChecked: $isSpayedNeutered, cardBg: cardBackgroundColor)
                DetailCheckCard(title: "Good with Kids", subtitle: "Comfortable around children", isChecked: $isGoodWithKids, cardBg: cardBackgroundColor)
                DetailCheckCard(title: "Good with Other Pets", subtitle: "Gets along with cats, dogs, etc.", isChecked: $isGoodWithPets, cardBg: cardBackgroundColor)
            }
            
            HStack(spacing: 12) {
                Button(action: { withAnimation { currentStep = 1 } }) {
                    Text("Back")
                        .font(.headline)
                        .foregroundColor(.primary)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(cardBackgroundColor)
                        .cornerRadius(16)
                }
                
                Button(action: { withAnimation { currentStep = 3 } }) {
                    Text("Continue")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(hex: "#C8623A"))
                        .cornerRadius(16)
                }
            }
            .padding(.top, 16)
        }
        .padding(.horizontal)
    }
    
    private var stepThreeView: some View {
        VStack(alignment: .leading, spacing: 18) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Photos")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                PhotosPicker(selection: $selectedItem, matching: .images) {
                    if let selectedImage = selectedImage {
                        Image(uiImage: selectedImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .cornerRadius(16)
                            .clipped()
                    } else {
                        VStack(spacing: 6) {
                            Image(systemName: "plus")
                                .font(.title2)
                                .foregroundColor(.gray)
                            Text("Add Photo")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                        .frame(width: 100, height: 100)
                        .background(cardBackgroundColor)
                        .cornerRadius(16)
                        .overlay(
                            RoundedRectangle(cornerRadius: 16)
                                .stroke(Color.gray.opacity(0.4), style: StrokeStyle(lineWidth: 1, dash: [4]))
                        )
                    }
                }
                .onChange(of: selectedItem) { newItem in
                    Task {
                        if let data = try? await newItem?.loadTransferable(type: Data.self),
                           let uiImage = UIImage(data: data) {
                            selectedImage = uiImage
                        }
                    }
                }
                
                Text("Tap to select a photo from your library.")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Tell us about \(displayName)")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                ZStack(alignment: .topLeading) {
                    if storyDescription.isEmpty {
                        Text("Describe \(displayName)'s personality, daily routine, what they love, why you're rehoming them, and any special needs...")
                            .font(.subheadline)
                            .foregroundColor(.gray.opacity(0.7))
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                    }
                    
                    TextEditor(text: $storyDescription)
                        .font(.subheadline)
                        .frame(height: 120)
                        .padding(8)
                        .scrollContentBackground(.hidden)
                        .background(cardBackgroundColor)
                        .cornerRadius(16)
                        .foregroundColor(.primary)
                }
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("SUMMARY")
                    .font(.caption2)
                    .fontWeight(.bold)
                    .foregroundColor(.secondary)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(displayName)
                        .font(.system(size: 20, weight: .bold, design: .serif))
                        .foregroundColor(.primary)
                    
                    // Dynamic summary string that updates as the user types
                    Text("\(breed.isEmpty ? "Mixed Breed" : breed) • \(selectedSpecies) • \(selectedAge) • \(selectedSize) • \(selectedGender)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    HStack(spacing: 4) {
                        Image(systemName: "mappin.and.ellipse")
                            .font(.caption2)
                            .foregroundColor(.orange)
                        Text(location.isEmpty ? "Location not specified" : location)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(cardBackgroundColor)
                .cornerRadius(16)
            }
            
            HStack(spacing: 12) {
                Button(action: { withAnimation { currentStep = 2 } }) {
                    Text("Back")
                        .font(.headline)
                        .foregroundColor(.primary)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(cardBackgroundColor)
                        .cornerRadius(16)
                }
                
                Button(action: { showPostAlert = true }) {
                    Text("Post Pet")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(hex: "#C8623A"))
                        .cornerRadius(16)
                }
            }
            .padding(.top, 8)
        }
        .padding(.horizontal)
    }
    
    private func submitPet() {
        var tags: [String] = []
        if isVaccinated { tags.append("Vaccinated") }
        if isSpayedNeutered { tags.append("Spayed/Neutered") }
        if isGoodWithKids { tags.append("Kid-friendly") }
        if isGoodWithPets { tags.append("Pet-friendly") }
        if tags.isEmpty { tags = ["Playful", "Trained"] }
        
        let descriptionText = storyDescription.trimmingCharacters(in: .whitespacesAndNewlines)
        let finalBio = descriptionText.isEmpty
        ? "\(displayName) is looking for a loving home! Super friendly, loves long walks, and gets along well with people and other pets."
        : descriptionText
        
        let finalLocation = location.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        ? "Nearby"
        : location
        
        let newPet = Pet(
            name: displayName,
            breed: breed.isEmpty ? "Mixed Breed" : breed,
            age: selectedAge,
            gender: selectedGender,
            category: selectedSpecies + "s",
            location: finalLocation,
            tags: tags,
            posterName: controller.user.name, // Automatically tied to current user
            likesCount: 0,
            imageName: "pawprint.fill",
            uiImage: selectedImage,
            bio: finalBio,
            isSaved: false,
            status: .active
        )
        
        controller.addPet(newPet)
        isPresented = false
    }
    
    // MARK: - Helper UI Components
    struct SelectionPill: View {
        let title: String
        let isSelected: Bool
        var cardBg: Color = Color.white
        let action: () -> Void
        
        var body: some View {
            Button(action: action) {
                Text(title)
                    .font(.caption)
                    .fontWeight(.medium)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(cardBg)
                    .foregroundColor(isSelected ? Color(hex: "#C8623A") : .primary)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(isSelected ? Color(hex: "#C8623A") : Color.clear, lineWidth: 1.5)
                    )
            }
        }
    }
    
    struct GenderButton: View {
        let title: String
        let isSelected: Bool
        var cardBg: Color = Color.white
        let action: () -> Void
        
        var body: some View {
            Button(action: action) {
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(cardBg)
                    .foregroundColor(isSelected ? Color(hex: "#C8623A") : .primary)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(isSelected ? Color(hex: "#C8623A") : Color.clear, lineWidth: 1.5)
                    )
            }
        }
    }
    
    struct DetailCheckCard: View {
        let title: String
        let subtitle: String
        @Binding var isChecked: Bool
        var cardBg: Color = Color.white
        
        var body: some View {
            Button(action: { isChecked.toggle() }) {
                HStack(spacing: 16) {
                    Image(systemName: isChecked ? "checkmark.circle.fill" : "plus")
                        .font(.title3)
                        .foregroundColor(isChecked ? .white : Color(hex: "#8C8275"))
                        .frame(width: 36, height: 36)
                        .background(isChecked ? Color(hex: "#C8623A") : Color.gray.opacity(0.15))
                        .clipShape(Circle())
                    
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title)
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        
                        Text(subtitle)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                }
                .padding()
                .background(cardBg)
                .cornerRadius(18)
            }
            .buttonStyle(PlainButtonStyle())
        }
    }
}
