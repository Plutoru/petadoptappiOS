//
//  AppController.swift
//  petadoptionapp
//
//  Created by STUDENT on 9/9/26.
//


import Foundation
import Combine
import SwiftUI

enum AppTheme: String, CaseIterable, Identifiable {
    case system = "Default"
    case dark = "Dark"
    
    var id: String { self.rawValue }
    var subtitle: String {
        switch self {
        case .system: return "Warm cream & terracotta"
        case .dark: return "Deep night tones"
        }
    }
    var iconName: String {
        switch self {
        case .system: return "sparkles"
        case .dark: return "moon.fill"
        }
    }
    var colorScheme: ColorScheme? {
        switch self {
        case .dark: return .dark
        case .system: return .light
        }
    }
}

private struct PersistedState: Codable {
    var pets: [Pet]
    var user: UserProfile
    var petUpdatesEnabled: Bool
    var isLoggedIn: Bool
}

class AppController: ObservableObject {
    @Published var pets: [Pet] = []
    @Published var user: UserProfile
    @Published var selectedCategory: String = "All"
    @Published var petUpdatesEnabled: Bool = false
    @Published var isLoggedIn: Bool = false
    
    @AppStorage("selectedTheme") var selectedTheme: AppTheme = .system
    
    let categories = ["All", "Dogs", "Cats", "Rabbits", "Other"]
    
    private var storageURL: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("app_state.json")
    }
    
    var postedCount: Int { pets.filter { $0.posterName == user.name && $0.status == .active }.count }
    var adoptedOutCount: Int { pets.filter { $0.posterName == user.name && $0.status == .adopted }.count }
    var adoptedPetsCount: Int { pets.filter { $0.adopterName == user.name && $0.posterName != user.name }.count }
    var savedCount: Int { pets.filter { $0.isSaved }.count }
    
    init() {
        self.user = UserProfile(
            name: "James Rivera",
            handle: "@jamesrivera",
            email: "james@example.com",
            password: "password123",
            location: "Austin, TX",
            isVerified: true,
            bio: "Animal lover & foster parent. I've rehomed pets to wonderful families. Ask me anything about the adoption process! 🐾🐾",
            postedCount: 0,
            adoptedOutCount: 0,
            savedCount: 0,
            showLocation: true
        )
        loadState()
    }
    
    // MARK: - Auth
    func login(email: String, password: String) -> Bool {
        if email.lowercased() == user.email.lowercased() && password == user.password {
            isLoggedIn = true
            save()
            return true
        }
        return false
    }
    
    func signUp(name: String, email: String, password: String) {
        self.user.name = name
        self.user.email = email
        self.user.password = password
        self.user.location = ""
        self.user.bio = ""
        
        let handleName = name.lowercased().replacingOccurrences(of: " ", with: "")
        self.user.handle = "@\(handleName)"
        self.isLoggedIn = true
        
        for i in 0..<pets.count {
            pets[i].isSaved = false
        }
        
        save()
    }
    
    func logout() {
        isLoggedIn = false
        save()
    }
    
    // MARK: - Persistence
    private func loadState() {
        guard FileManager.default.fileExists(atPath: storageURL.path) else {
            loadSamplePets()
            save()
            return
        }
        do {
            let data = try Data(contentsOf: storageURL)
            let state = try JSONDecoder().decode(PersistedState.self, from: data)
            self.pets = state.pets
            self.user = state.user
            self.petUpdatesEnabled = state.petUpdatesEnabled
            self.isLoggedIn = state.isLoggedIn
        } catch {
            print("Failed to load persisted state: \(error). Falling back to sample data.")
            loadSamplePets()
            save()
        }
    }
    
    func save() {
        let state = PersistedState(pets: pets, user: user, petUpdatesEnabled: petUpdatesEnabled, isLoggedIn: isLoggedIn)
        do {
            let data = try JSONEncoder().encode(state)
            try data.write(to: storageURL, options: .atomic)
        } catch {
            print("Failed to save state: \(error)")
        }
    }
    
    func deleteAllData() {
        try? FileManager.default.removeItem(at: storageURL)
        self.petUpdatesEnabled = false
        self.selectedCategory = "All"
        self.isLoggedIn = false
        self.user = UserProfile(
            name: "James Rivera",
            handle: "@jamesrivera",
            email: "james@example.com",
            password: "password123",
            location: "Austin, TX",
            isVerified: true,
            bio: "Animal lover & foster parent. I've rehomed pets to wonderful families. Ask me anything about the adoption process! 🐾🐾",
            postedCount: 0,
            adoptedOutCount: 0,
            savedCount: 0,
            showLocation: true
        )
        loadSamplePets()
        save()
    }
    
    private func loadSamplePets() {
        self.pets = [
            Pet(name: "Mango", breed: "Golden Retriever", age: "8 months", gender: "Male", category: "Dogs", location: "San Francisco, CA", tags: ["Playful", "Trained", "Kid-friendly"], posterName: "Sarah Chen", likesCount: 34, imageName: "dog_mango", uiImage: nil, bio: "Mango is an energetic and joyful Golden Retriever puppy who loves playing fetch and going on long walks.", isSaved: true, status: .active),
            Pet(name: "Luna", breed: "Domestic Shorthair", age: "2 years", gender: "Female", category: "Cats", location: "Austin, TX", tags: ["Indoor", "Calm"], posterName: "James Rivera", likesCount: 18, imageName: "cat_luna", uiImage: nil, bio: "Luna is a peaceful indoor cat who loves sunbathing by the window and curling up on your lap during quiet evenings.", isSaved: true, status: .active),
            Pet(name: "Biscuit", breed: "Holland Lop", age: "1 year", gender: "Male", category: "Rabbits", location: "Portland, OR", tags: ["Friendly"], posterName: "Alex M.", likesCount: 42, imageName: "rabbit_biscuit", uiImage: nil, bio: "Biscuit is a sweet and gentle Holland Lop bunny who enjoys munching on fresh carrots and exploring safe indoor spaces.", isSaved: false, status: .active),
            Pet(name: "Oreo", breed: "French Bulldog", age: "1.5 years", gender: "Male", category: "Dogs", location: "Austin, TX", tags: ["Lap Dog", "Vaccinated"], posterName: "James Rivera", likesCount: 29, imageName: "dog_oreo", uiImage: nil, bio: "Oreo is a charming French Bulldog with an affectionate personality. He loves belly rubs and hanging out close by.", isSaved: false, status: .active),
            Pet(name: "Milo", breed: "Siamese", age: "5 months", gender: "Male", category: "Cats", location: "Seattle, WA", tags: ["Curious", "Spayed/Neutered"], posterName: "Emma Watson", likesCount: 51, imageName: "cat_milo", uiImage: nil, bio: "Milo is a super curious and talkative Siamese kitten who loves interactive toys and following you around the house.", isSaved: true, status: .active),
            Pet(name: "Bella", breed: "Cockatiel", age: "2 years", gender: "Female", category: "Other", location: "Austin, TX", tags: ["Vocal", "Hand-tamed"], posterName: "James Rivera", likesCount: 12, imageName: "bird_bella", uiImage: nil, bio: "Bella is a hand-tamed Cockatiel who loves singing cheerful tunes and sitting comfortably on your shoulder.", isSaved: false, status: .active),
            Pet(name: "Rocky", breed: "German Shepherd", age: "3 years", gender: "Male", category: "Dogs", location: "Denver, CO", tags: ["Loyal", "Active", "Guard Dog"], posterName: "Michael B.", likesCount: 67, imageName: "dog_rocky", uiImage: nil, bio: "Rocky is a highly intelligent and loyal companion. He needs an active family who loves hiking and the outdoors.", isSaved: false, status: .active),
            Pet(name: "Daisy", breed: "Beagle", age: "4 years", gender: "Female", category: "Dogs", location: "Chicago, IL", tags: ["Gentle", "Good with Kids"], posterName: "Emily R.", likesCount: 22, imageName: "dog_daisy", uiImage: nil, bio: "Daisy is a sweet and gentle soul who loves sniffing around the backyard and cuddling on the couch.", isSaved: false, status: .active),
            Pet(name: "Charlie", breed: "Maine Coon", age: "2.5 years", gender: "Male", category: "Cats", location: "New York, NY", tags: ["Fluffy", "Independent"], posterName: "David L.", likesCount: 85, imageName: "cat_charlie", uiImage: nil, bio: "Charlie is a majestic Maine Coon. He is very independent but loves a good head scratch when he's in the mood.", isSaved: false, status: .active),
            Pet(name: "Cleo", breed: "Lionhead", age: "6 months", gender: "Female", category: "Rabbits", location: "Miami, FL", tags: ["Cute", "Playful"], posterName: "Jessica P.", likesCount: 19, imageName: "rabbit_cleo", uiImage: nil, bio: "Cleo is an adorable little bunny with a big personality. She loves exploring and chewing on safe wooden toys.", isSaved: false, status: .active)
        ]
    }
    
    // MARK: - Mutations
    func toggleSave(for pet: Pet) {
        if let index = pets.firstIndex(where: { $0.id == pet.id }) {
            pets[index].isSaved.toggle()
            save()
        }
    }
    
    func markAsAdopted(pet: Pet) {
        if let index = pets.firstIndex(where: { $0.id == pet.id }) {
            pets[index].status = .adopted
            pets[index].adopterName = user.name
            save()
        }
    }
    
    func adoptPet(pet: Pet) {
        if let index = pets.firstIndex(where: { $0.id == pet.id }) {
            pets[index].status = .adopted
            pets[index].adopterName = user.name
            save()
        }
    }
    
    func removeAdoption(pet: Pet) {
        if let index = pets.firstIndex(where: { $0.id == pet.id }) {
            pets[index].status = .active
            pets[index].adopterName = nil
            save()
        }
    }
    
    func deletePet(pet: Pet) {
        if pet.posterName == user.name {
            pets.removeAll(where: { $0.id == pet.id })
        } else if pet.adopterName == user.name {
            removeAdoption(pet: pet)
        }
        save()
    }
    
    func addPet(_ pet: Pet) {
        pets.insert(pet, at: 0)
        save()
    }
    
    // NEW: Update pet details
    func updatePet(petID: UUID, newAge: String, newLocation: String, newBio: String) {
        if let index = pets.firstIndex(where: { $0.id == petID }) {
            pets[index].bio = newBio
            pets[index].location = newLocation
            // Since age is a String and not a var in the struct, we'll need to update the struct to allow modifying it,
            // but for now, let's just update the bio and location.
            // *Wait, in Pet.swift, 'age' is a 'let'. I will update Pet.swift to make it 'var'.*
            pets[index].age = newAge
            save()
        }
    }
    
    func updateProfile(name: String, bio: String, location: String) {
        user.name = name
        user.bio = bio
        user.location = location
        save()
    }
    
    func updateProfileImage(_ image: UIImage?) {
        user.uiImage = image
        save()
    }
}
